;(function(window) {

  var svgSprite = '<svg>' +
    '' +
    '<symbol id="icon-fanhui" viewBox="0 0 1265 1024">' +
    '' +
    '<path d="M1043.425724 822.10448l-619.974878 0c-13.485382 0-18.137484-4.025517-31.946011-15.973991l-0.3261-0.288663L96.676628 539.406024c-6.620527-6.112165-10.409596-14.783872-10.395803-23.793503 0.013793-9.010616 3.828477-17.671486 10.466737-23.762962l0.146794-0.133987 293.445975-263.879215c13.910987-15.681387 25.894929-17.017315 36.066107-17.017315l617.019286 0c17.024211 0 30.875102 13.85089 30.875102 30.875102l0 549.537204C1074.300825 808.254575 1060.45092 822.10448 1043.425724 822.10448zM424.74835 782.696584l610.145564 0L1034.893914 250.226939 426.407423 250.226939c-0.876826 0-2.052166 0-2.542795 0.057141-0.355656 0.197039-1.840349 1.130021-4.51516 4.246201l-0.828551 0.964508L129.185187 515.676559l288.270733 260.795547C420.270628 778.9085 422.965143 781.237506 424.74835 782.696584z"  ></path>' +
    '' +
    '<path d="M929.232477 603.218245l-86.614615-86.352553 86.438265-86.701313c8.041181-8.065811 8.002759-21.104899-0.086697-29.123421l0 0c-8.089456-8.017537-21.165981-7.979114-29.208148 0.086697l-86.353538 86.615601-86.298367-86.03729c-8.065811-8.041181-21.104899-8.002759-29.123421 0.086697-8.017537 8.089456-7.979114 21.165981 0.086697 29.208148l86.212655 85.952563-86.036305 86.297382c-8.042166 8.065811-8.002759 21.104899 0.087683 29.123421l0 0c8.089456 8.017537 21.165981 7.979114 29.208148-0.086697l85.951578-86.212655 86.700328 86.438265c8.065811 8.042166 21.104899 8.002759 29.123421-0.087683l0 0C937.336711 624.335952 937.298288 611.259427 929.232477 603.218245z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-0032" viewBox="0 0 1088 1024">' +
    '' +
    '<path d="M994.714112 544.640736 564.07008 978.063104 610.371552 1024 1063.836512 567.609184C1096.068224 535.401504 1096.068224 485.421344 1063.753984 453.13088L610.289024 0 564.152608 46.102432 997.81168 479.442048 0 479.442048 0 544.640736 994.714112 544.640736 994.714112 544.640736Z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-shoudiantong" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M792.685714 0H247.405714c-20.114286 0-36.571429 16.457143-36.571428 36.571429v224.365714c0 98.742857 55.954286 184.868571 138.605714 229.12v497.371428c0 20.114286 16.457143 36.571429 36.571429 36.571429h268.068571c20.114286 0 36.571429-16.457143 36.571429-36.571429V489.874286c82.651429-44.251429 138.605714-130.194286 138.605714-229.12V36.571429c0-20.114286-16.457143-36.571429-36.571429-36.571429zM283.977143 183.588571V73.142857h472.137143v110.445714H283.977143z m138.605714 620.068572V467.931429c0-13.531429-7.497143-25.782857-19.382857-32.182858l-19.382857-10.422857c-61.622857-33.097143-100.022857-96.182857-100.022857-164.571428v-4.205715h472.137143v4.205715c0 68.388571-38.4 131.474286-100.022858 164.571428l-19.382857 10.422857c-11.885714 6.4-19.382857 18.834286-19.382857 32.182858v335.725714H422.582857z m0 147.2v-74.057143h194.925714V950.857143H422.582857z" fill="" ></path>' +
    '' +
    '<path d="M520.045714 549.12c-20.114286 0-36.571429 16.457143-36.571428 36.571429v73.142857c0 20.114286 16.457143 36.571429 36.571428 36.571428s36.571429-16.457143 36.571429-36.571428v-73.142857c0-20.297143-16.457143-36.571429-36.571429-36.571429z" fill="" ></path>' +
    '' +
    '</symbol>' +
    '' +
    '</svg>'
  var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
  var shouldInjectCss = script.getAttribute("data-injectcss")

  /**
   * document ready
   */
  var ready = function(fn) {
    if (document.addEventListener) {
      if (~["complete", "loaded", "interactive"].indexOf(document.readyState)) {
        setTimeout(fn, 0)
      } else {
        var loadFn = function() {
          document.removeEventListener("DOMContentLoaded", loadFn, false)
          fn()
        }
        document.addEventListener("DOMContentLoaded", loadFn, false)
      }
    } else if (document.attachEvent) {
      IEContentLoaded(window, fn)
    }

    function IEContentLoaded(w, fn) {
      var d = w.document,
        done = false,
        // only fire once
        init = function() {
          if (!done) {
            done = true
            fn()
          }
        }
        // polling for no errors
      var polling = function() {
        try {
          // throws errors until after ondocumentready
          d.documentElement.doScroll('left')
        } catch (e) {
          setTimeout(polling, 50)
          return
        }
        // no errors, fire

        init()
      };

      polling()
        // trying to always fire before onload
      d.onreadystatechange = function() {
        if (d.readyState == 'complete') {
          d.onreadystatechange = null
          init()
        }
      }
    }
  }

  /**
   * Insert el before target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var before = function(el, target) {
    target.parentNode.insertBefore(el, target)
  }

  /**
   * Prepend el to target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var prepend = function(el, target) {
    if (target.firstChild) {
      before(el, target.firstChild)
    } else {
      target.appendChild(el)
    }
  }

  function appendSvg() {
    var div, svg

    div = document.createElement('div')
    div.innerHTML = svgSprite
    svgSprite = null
    svg = div.getElementsByTagName('svg')[0]
    if (svg) {
      svg.setAttribute('aria-hidden', 'true')
      svg.style.position = 'absolute'
      svg.style.width = 0
      svg.style.height = 0
      svg.style.overflow = 'hidden'
      prepend(svg, document.body)
    }
  }

  if (shouldInjectCss && !window.__iconfont__svg__cssinject__) {
    window.__iconfont__svg__cssinject__ = true
    try {
      document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
    } catch (e) {
      console && console.log(e)
    }
  }

  ready(appendSvg)


})(window)